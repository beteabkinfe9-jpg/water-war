import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';

class Player {
  Player({required this.id, required this.name, this.hearts = 3, this.kills = 0, this.zone = 'Unknown'});
  final String id; final String name; int hearts; int kills; String zone;
  bool get alive => hearts > 0;
  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'hearts': hearts, 'kills': kills, 'zone': zone};
  factory Player.fromJson(Map<String, dynamic> j) => Player(id: j['id'], name: j['name'], hearts: (j['hearts'] as num?)?.toInt() ?? 3, kills: (j['kills'] as num?)?.toInt() ?? 0, zone: j['zone'] ?? 'Unknown');
}
class TagReport { TagReport({required this.id, required this.attackerId, required this.attackerName, required this.targetId}); final String id, attackerId, attackerName, targetId; }

class LanGame extends ChangeNotifier {
  static const port = 4040;
  final String myId = DateTime.now().microsecondsSinceEpoch.toString();
  final Map<String, Player> _players = {};
  final Map<String, Socket> _clients = {};
  final Map<String, StringBuffer> _buffers = {};
  final Map<String, TagReport> _hostReports = {};
  final List<TagReport> pendingReports = [];
  final StringBuffer _clientBuffer = StringBuffer();
  ServerSocket? _server; Socket? _socket; Player? me; bool isHost = false; String? hostAddress;
  String status = 'Not connected', lastNotice = 'Have fun and play safely.';
  List<Player> get players => _players.values.toList();

  Future<void> startHost(String name) async {
    isHost = true; me = Player(id: 'host', name: name); _players['host'] = me!;
    _server = await ServerSocket.bind(InternetAddress.anyIPv4, port, shared: true);
    final interfaces = await NetworkInterface.list(type: InternetAddressType.IPv4);
    final addresses = interfaces.expand((i) => i.addresses).where((a) => !a.isLoopback && !a.address.startsWith('169.254.'));
    hostAddress = addresses.isEmpty ? 'Find hotspot IP in network settings' : addresses.first.address;
    status = 'Room listening on port $port. Share host IP with players.'; notifyListeners();
    _server!.listen(_accept);
  }
  void _accept(Socket s) {
    final key = '${s.remoteAddress.address}:${s.remotePort}'; _buffers[key] = StringBuffer();
    s.listen((data) { final b = _buffers[key]!; b.write(utf8.decode(data, allowMalformed: true)); final lines = b.toString().split('\n'); b..clear()..write(lines.removeLast()); for (final line in lines) { if (line.trim().isNotEmpty) { try { _hostMessage(s, jsonDecode(line)); } catch (_) {} } } }, onDone: () => _buffers.remove(key), onError: (_) => _buffers.remove(key));
  }
  Future<void> join(String ip, String name) async {
    if (ip.isEmpty) throw Exception('Enter the host IP address.');
    isHost = false; _socket = await Socket.connect(ip, port, timeout: const Duration(seconds: 8));
    _socket!.listen(_clientData, onError: (_) { status = 'Connection lost'; notifyListeners(); });
    me = Player(id: myId, name: name); status = 'Connected. Waiting for room state...'; _send({'type': 'join', 'player': me!.toJson()}); notifyListeners();
  }
  void _send(Map<String, dynamic> m) => _socket?.write('${jsonEncode(m)}\n');
  void _broadcast(Map<String, dynamic> m) { final line = '${jsonEncode(m)}\n'; for (final s in _clients.values) { try { s.write(line); } catch (_) {} } }
  void _hostMessage(Socket socket, Map<String, dynamic> m) {
    switch (m['type']) {
      case 'join':
        final p = Player.fromJson(Map<String, dynamic>.from(m['player'])); _players[p.id] = p; _clients[p.id] = socket; _broadcastState(); lastNotice = '${p.name} joined.'; break;
      case 'zone':
        final p = _players[m['id']]; if (p != null) { p.zone = _short(m['zone'] as String); _broadcastState(); } break;
      case 'report':
        _deliverReport(m['attacker'] as String, m['target'] as String); break;
      case 'response':
        _resolveReport(m['reportId'] as String, m['accepted'] == true); break;
    }
    notifyListeners();
  }
  void _deliverReport(String attackerId, String targetId) {
    final attacker = _players[attackerId], target = _players[targetId];
    if (attacker == null || target == null || !attacker.alive || !target.alive || attackerId == targetId) return;
    final id = DateTime.now().microsecondsSinceEpoch.toString();
    final report = TagReport(id: id, attackerId: attackerId, attackerName: attacker.name, targetId: targetId);
    if (targetId == 'host') { pendingReports.add(report); lastNotice = '${attacker.name} reported a tag against you.'; }
    else { _clients[targetId]?.write('${jsonEncode({'type': 'incoming', 'id': id, 'attackerId': attackerId, 'attackerName': attacker.name})}\n'); _hostReports[id] = report; }
  }
  void _resolveReport(String id, bool accepted) {
    final r = _hostReports.remove(id); if (r == null) return;
    if (accepted) _applyTag(r); else lastNotice = 'A tag report was declined.';
    _broadcastState();
  }
  void _applyTag(TagReport r) {
    final target = _players[r.targetId];
    final attacker = _players[r.attackerId];
    if (target == null || attacker == null || target.hearts <= 0 || !attacker.alive) return;
    target.hearts--;
    attacker.kills++;
    lastNotice = '${attacker.name} received a confirmed tag.';
  }
  void _clientData(List<int> data) {
    _clientBuffer.write(utf8.decode(data, allowMalformed: true)); final lines = _clientBuffer.toString().split('\n'); _clientBuffer..clear()..write(lines.removeLast());
    for (final line in lines) { if (line.trim().isEmpty) continue; final m = jsonDecode(line) as Map<String, dynamic>;
      if (m['type'] == 'state') { _players..clear()..addEntries((m['players'] as List).map((x) { final p = Player.fromJson(Map<String, dynamic>.from(x)); return MapEntry(p.id, p); })); me = _players[myId]; status = 'Connected to host'; }
      if (m['type'] == 'incoming') { pendingReports.add(TagReport(id: m['id'], attackerId: m['attackerId'], attackerName: m['attackerName'], targetId: myId)); lastNotice = 'A tag report needs your review.'; }
      if (m['type'] == 'notice') lastNotice = m['text']; notifyListeners();
    }
  }
  void _broadcastState() => _broadcast({'type': 'state', 'players': _players.values.map((p) => p.toJson()).toList()});
  String _short(String s) => s.length > 32 ? s.substring(0, 32) : s;
  void updateZone(String z) { final clean = _short(z.trim().isEmpty ? 'Unknown' : z.trim()); if (isHost) { me?.zone = clean; _broadcastState(); } else { _send({'type': 'zone', 'id': myId, 'zone': clean}); } notifyListeners(); }
  void reportTag(String targetId) { if (isHost) { _deliverReport('host', targetId); } else { _send({'type': 'report', 'attacker': myId, 'target': targetId}); lastNotice = 'Tag report sent. Waiting for review.'; } notifyListeners(); }
  void respondToReport(String id, bool accepted) {
    final index = pendingReports.indexWhere((r) => r.id == id); if (index < 0) return; final r = pendingReports.removeAt(index);
    if (isHost) { if (accepted) _applyTag(r); _broadcastState(); }
    else { _send({'type': 'response', 'reportId': id, 'accepted': accepted}); }
    lastNotice = accepted ? 'Tag confirmed.' : 'Tag declined.'; notifyListeners();
  }
  void broadcastStatus(String text) { lastNotice = text; _broadcast({'type': 'notice', 'text': text}); notifyListeners(); }
  Future<void> close() async { await _socket?.close(); await _server?.close(); for (final s in _clients.values) { await s.close(); } _clients.clear(); status = 'Disconnected'; notifyListeners(); }
  @override
  void dispose() { close(); super.dispose(); }
}
