import 'package:flutter/material.dart';
import 'lan_game.dart';

void main() => runApp(const WaterWarApp());

class WaterWarApp extends StatelessWidget {
  const WaterWarApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'WATER WAR', debugShowCheckedModeBanner: false,
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xff16a6d7), brightness: Brightness.dark), useMaterial3: true, scaffoldBackgroundColor: const Color(0xff081522)),
    home: const LobbyPage(),
  );
}

class LobbyPage extends StatefulWidget {
  const LobbyPage({super.key});
  @override
  State<LobbyPage> createState() => _LobbyPageState();
}
class _LobbyPageState extends State<LobbyPage> {
  final name = TextEditingController(text: 'Player');
  final ip = TextEditingController();
  final game = LanGame();
  String message = 'Play together on the same Wi-Fi hotspot. No internet required.';
  bool busy = false;
  Future<void> run(Future<void> Function() action) async {
    setState(() { busy = true; message = 'Connecting...'; });
    try {
      await action();
      if (!mounted) return;
      Navigator.push(context, MaterialPageRoute(builder: (_) => GamePage(game: game)));
    } catch (e) { if (mounted) setState(() => message = '$e'); }
    finally { if (mounted) setState(() => busy = false); }
  }
  @override
  void dispose() { name.dispose(); ip.dispose(); game.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => Scaffold(body: SafeArea(child: Center(child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 520), child: ListView(padding: const EdgeInsets.all(24), children: [
    const SizedBox(height: 30), const Icon(Icons.water_drop, size: 66, color: Color(0xff35c5f2)),
    const Text('WATER WAR', textAlign: TextAlign.center, style: TextStyle(fontSize: 34, fontWeight: FontWeight.w900, letterSpacing: 3)),
    const Text('OFFLINE TEAM TAG', textAlign: TextAlign.center, style: TextStyle(color: Color(0xff7fcde8), letterSpacing: 2)),
    const SizedBox(height: 32), TextField(controller: name, maxLength: 18, decoration: const InputDecoration(labelText: 'Player name', border: OutlineInputBorder())),
    const SizedBox(height: 12), FilledButton.icon(onPressed: busy ? null : () => run(() => game.startHost(name.text.trim().isEmpty ? 'Host' : name.text.trim())), icon: const Icon(Icons.wifi_tethering), label: const Padding(padding: EdgeInsets.all(14), child: Text('HOST A GAME'))),
    const Text('Host: turn on your hotspot first, then create a room.', textAlign: TextAlign.center, style: TextStyle(color: Colors.white60)),
    const Divider(height: 34), TextField(controller: ip, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Host IP address', hintText: 'Example: 192.168.43.1', border: OutlineInputBorder())),
    const SizedBox(height: 12), OutlinedButton.icon(onPressed: busy ? null : () => run(() => game.join(ip.text.trim(), name.text.trim().isEmpty ? 'Player' : name.text.trim())), icon: const Icon(Icons.login), label: const Padding(padding: EdgeInsets.all(14), child: Text('JOIN A GAME'))),
    const Text('Client: connect to the host hotspot, then enter the host IP.', textAlign: TextAlign.center, style: TextStyle(color: Colors.white60)),
    if (busy) const Padding(padding: EdgeInsets.all(12), child: Center(child: CircularProgressIndicator())),
    Text(message, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white70)),
    const SizedBox(height: 20), const Text('Play only in an agreed safe area. This app tracks broad zones, not exact positions. Keep roads and non-participants outside the game.', textAlign: TextAlign.center, style: TextStyle(fontSize: 12, color: Colors.white38)),
  ])))));
}

class GamePage extends StatefulWidget {
  const GamePage({super.key, required this.game}); final LanGame game;
  @override
  State<GamePage> createState() => _GamePageState();
}
class _GamePageState extends State<GamePage> {
  final target = TextEditingController();
  final zone = TextEditingController(text: 'Central zone');
  @override
  void dispose() { target.dispose(); zone.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) { final g = widget.game; return Scaffold(appBar: AppBar(title: const Text('WATER WAR'), actions: [IconButton(onPressed: () async { await g.close(); if (context.mounted) Navigator.pop(context); }, icon: const Icon(Icons.exit_to_app))]), body: AnimatedBuilder(animation: g, builder: (context, _) {
    final me = g.me;
    final eligible = g.players.where((p) => p.id != g.myId && p.alive).toList();
    return ListView(padding: const EdgeInsets.all(16), children: [
      Card(child: ListTile(title: Text(g.isHost ? 'HOST ROOM' : 'CONNECTED'), subtitle: Text('${g.hostAddress ?? 'Local room'}  •  ${g.status}'))),
      Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(children: [Text(me?.name ?? 'You', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)), Row(mainAxisAlignment: MainAxisAlignment.center, children: List.generate(3, (i) => Icon(Icons.favorite, size: 30, color: i < (me?.hearts ?? 3) ? Colors.redAccent : Colors.white24))), Text('${me?.hearts ?? 3}/3 hearts  •  ${me?.kills ?? 0} confirmed tags')]))),
      const Text('PLAYERS', style: TextStyle(fontWeight: FontWeight.bold)),
      ...g.players.map((p) => Card(child: ListTile(leading: Icon(p.alive ? Icons.person_pin_circle : Icons.person_off, color: p.alive ? Colors.lightGreenAccent : Colors.white38), title: Text(p.name), subtitle: Text('${p.zone} • ${p.hearts} hearts • ${p.kills} tags'), trailing: Text(p.alive ? 'ALIVE' : 'OUT')))),
      const SizedBox(height: 12), const Text('MY APPROXIMATE ZONE', style: TextStyle(fontWeight: FontWeight.bold)),
      TextField(controller: zone, decoration: const InputDecoration(border: OutlineInputBorder(), helperText: 'Choose a broad area name; no GPS coordinates are shared.')),
      OutlinedButton(onPressed: () => g.updateZone(zone.text), child: const Text('UPDATE MY ZONE')),
      const SizedBox(height: 12), const Text('REPORT A TAG', style: TextStyle(fontWeight: FontWeight.bold)),
      DropdownButtonFormField<String>(value: eligible.any((p) => p.id == target.text) ? target.text : null, decoration: const InputDecoration(border: OutlineInputBorder(), labelText: 'Choose player'), items: eligible.map((p) => DropdownMenuItem(value: p.id, child: Text(p.name))).toList(), onChanged: (v) => setState(() => target.text = v ?? '')),
      FilledButton(onPressed: target.text.isEmpty ? null : () => g.reportTag(target.text), child: const Text('SEND TAG REPORT')),
      if (g.pendingReports.isNotEmpty) ...[
        const SizedBox(height: 12), const Text('TAG REPORTS TO REVIEW', style: TextStyle(fontWeight: FontWeight.bold)),
        ...g.pendingReports.map((r) => Card(child: ListTile(title: Text('${r.attackerName} says they tagged you'), subtitle: const Text('Confirm only if this happened.'), trailing: Wrap(children: [IconButton(onPressed: () => g.respondToReport(r.id, true), icon: const Icon(Icons.check_circle, color: Colors.lightGreenAccent)), IconButton(onPressed: () => g.respondToReport(r.id, false), icon: const Icon(Icons.cancel, color: Colors.redAccent))])))),
      ],
      const SizedBox(height: 12), if (g.isHost) OutlinedButton(onPressed: () => g.broadcastStatus('Host ended the match.'), child: const Text('ANNOUNCE END OF MATCH')),
      Text(g.lastNotice, textAlign: TextAlign.center, style: const TextStyle(color: Color(0xff7fcde8))),
    ]);
  })); }
}
