# WATER WAR — offline team-tag prototype

A Flutter starter for a local-network team-tag game. The first build provides a host/client lobby, basic TCP hotspot networking, player list, three hearts, confirmed tag reports, kill counts, and manually selected broad zones. It does not share GPS coordinates.

## Build with GitHub Actions (no local PC required)
1. Create a GitHub repository and upload the contents of this project ZIP to its root, preserving the `.github/workflows/build-apk.yml` file.
2. Open the repository's **Actions** tab, select **Build WATER WAR APK**, then choose **Run workflow**.
3. When the run succeeds, open it and download the `water-war-apk` artifact.
4. Extract the artifact ZIP; `app-release.apk` is the installable Android test build.

For a free GitHub account, a public repository is usually the simplest way to use hosted Actions. Do not upload passwords, private keys, or personal information.

## Hotspot test
1. Host enables their phone hotspot and taps **HOST A GAME**.
2. Friends connect to that hotspot, tap **JOIN A GAME**, and enter the host's hotspot-side IP address.
3. Use broad manually chosen zones (for example, North field or Central zone). This prototype intentionally does not transmit exact GPS coordinates.

## Limitations
This is an early prototype, not release-ready software. Test on the exact phones and hotspot models first. It needs more work on connection recovery, robust player identity, host moderation, and user-friendly discovery. iPhones require a separate iOS build and Apple signing; APKs only install on Android. Use only with consenting participants in a designated safe play area, away from roads and non-participants.
